# eBike Application Using Streamlit

## Description 
A simple app which implements the CRUD functionalities for demo DBMS class.

```
    C - Create
    R - Read
    U - Update
    D - Delete
```

## Technologies
The project is created using: 
* Python
* Streamlit
* MySQL
* Pandas
* Plotly
